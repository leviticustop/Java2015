package cn.itcast.surveypark.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.surveypark.domain.security.Right;

/**
 * rightDao
 */
@Repository("rightDao")
public class RightDaoImpl extends BaseDaoImpl<Right> {
}
