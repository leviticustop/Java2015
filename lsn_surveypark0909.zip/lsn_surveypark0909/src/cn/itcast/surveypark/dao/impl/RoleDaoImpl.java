package cn.itcast.surveypark.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.surveypark.domain.security.Role;

/**
 * roleDao
 */
@Repository("roleDao")
public class RoleDaoImpl extends BaseDaoImpl<Role> {
}
