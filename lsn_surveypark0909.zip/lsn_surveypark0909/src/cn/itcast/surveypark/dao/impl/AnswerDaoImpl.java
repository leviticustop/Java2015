package cn.itcast.surveypark.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.surveypark.domain.Answer;

/**
 * answerDao
 */
@Repository("answerDao")
public class AnswerDaoImpl extends BaseDaoImpl<Answer> {
}
