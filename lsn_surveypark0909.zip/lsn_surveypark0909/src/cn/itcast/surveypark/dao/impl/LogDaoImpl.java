package cn.itcast.surveypark.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.surveypark.domain.Log;

/**
 * logDao
 */
@Repository("logDao")
public class LogDaoImpl extends BaseDaoImpl<Log> {
}
