package cn.itcast.surveypark.dao.impl;

import org.springframework.stereotype.Repository;

import cn.itcast.surveypark.domain.Page;

/**
 * pageDao
 */
@Repository("pageDao")
public class PageDaoImpl extends BaseDaoImpl<Page> {
}
