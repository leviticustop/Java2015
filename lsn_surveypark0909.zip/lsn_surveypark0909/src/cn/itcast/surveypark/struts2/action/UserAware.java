package cn.itcast.surveypark.struts2.action;

import cn.itcast.surveypark.domain.User;

/**
 * �û���ע�ӿ�
 */
public interface UserAware {
	public void setUser(User user);
}
